*** Road Connect ***
This is just a game I made for a technical test for a company.


** How to play **
Click to rotate the roads to combine them in a big single road.

** License and Version **
v1.0.13
This is under GNU License, except the assets, which are from infinitygames.io

** Known Issues **
- Click on button sometimes doesn't work.
- Some very small sprite bleeding.
- Double curve piece is working as a Cross piece.